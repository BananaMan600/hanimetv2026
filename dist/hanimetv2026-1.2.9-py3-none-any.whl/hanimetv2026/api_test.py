import unittest
from types import SimpleNamespace

from hanimetv2026.api import Video


class VideoMetadataMappingTests(unittest.TestCase):
    def test_uses_new_video_payload_shape(self):
        args = SimpleNamespace(
            title_as_filename=False,
            output_dir=".",
            poster_download=False,
            only_posters=False,
            no_thumbnail=True,
            working_dir=None,
            verbose=False,
            sleep_time=0,
        )

        payload = {
            "success": True,
            "video": {
                "id": 1,
                "name": "Example Video",
                "slug": "example-video",
                "description": "<p>Example</p>",
                "brand": "Example Brand",
                "views": 42,
                "likes": 7,
                "dislikes": 1,
                "downloads": 3,
                "monthly_rank": 2,
                "released_at": "2024-01-02T03:04:05.000Z",
                "created_at": "2023-01-02T03:04:05.000Z",
                "poster_url": "https://example.com/poster.jpg",
                "cover_url": "https://example.com/cover.jpg",
                "tags": ["tag-a", "tag-b"],
            },
            "franchise": {
                "id": 99,
                "title": "Example Franchise",
                "slug": "example-franchise",
                "videos": [
                    {"slug": "first-video"},
                    {"slug": "second-video"},
                ],
            },
        }

        video = Video(payload, args)

        self.assertEqual(video.title, "Example Video")
        self.assertEqual(video.slug, "example-video")
        self.assertEqual(video.metadata.brand, "Example Brand")
        self.assertEqual(video.metadata.views, 42)
        self.assertEqual(video.metadata.tags, ["tag-a", "tag-b"])
        self.assertEqual(video.metadata.thumbnail, "https://example.com/poster.jpg")
        self.assertEqual(video.metadata.cover, "https://example.com/cover.jpg")
        self.assertEqual(video.metadata.franchise_title, "Example Franchise")
        self.assertEqual(video.metadata.franchise_videos, ["first-video", "second-video"])
        self.assertEqual(video.metadata.description, "Example")


if __name__ == "__main__":
    unittest.main()
